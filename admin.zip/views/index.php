<?php require ('partials/header.php'); ?>

<?php require ('partials/menu.php'); ?>

<h1>tableau de bord de l'admin</h1>